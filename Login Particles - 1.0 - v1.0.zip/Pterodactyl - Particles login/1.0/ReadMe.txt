﻿Thanks for downloading this login theme Amowyn

Move the contents of "Panel Files" to /var/www/pterodactyl


Install NodeJS

# Ubuntu/Debian
	curl -sL https://deb.nodesource.com/setup_16.x | sudo -E bash -
	apt install -y nodejs

# CentOS
	curl -sL https://rpm.nodesource.com/setup_16.x | sudo -E bash -
	yum install -y nodejs # CentOS 7
	dnf install -y nodejs # CentOS 8

Then run the following commands

 - cd /var/www/pterodactyl
 - yarn add react-tsparticles
 - npm i -g yarn
 - cd /var/www/pterodactyl
 - yarn install
 - yarn run build:production

 If you need help or find issues join my discord for support, 
 https://discord.gg/mWpexJ8P8h


Edited and updated from Notil

Version: 1.0
